const CACHE_NAME = 'sen-voice-shell-v1';
const CORE_ASSETS = ['./', './index.html', './precache-manifest.json', './manifest.webmanifest', './icon.svg', './icon-192.png', './icon-512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    // During install, precache the built app bundles (including the inference worker
    // and any emitted WASM runtime assets) so a later reload can work offline.
    let manifestFiles = [];
    try {
      const response = await fetch('./precache-manifest.json', { cache: 'no-store' });
      if (response.ok) manifestFiles = await response.json();
    } catch { /* The app remains usable online even if precache manifest is missing. */ }
    const files = [...new Set([...CORE_ASSETS, ...manifestFiles])];
    await Promise.all(files.map(async (path) => {
      try { await cache.add(path); } catch { /* Continue if a nonessential asset fails to cache. */ }
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith('sen-voice-shell-') && key !== CACHE_NAME).map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        const cache = await caches.open(CACHE_NAME);
        cache.put(request, response.clone()).catch(() => {});
        return response;
      } catch {
        const cache = await caches.open(CACHE_NAME);
        return (await cache.match(request)) || (await cache.match('./index.html')) || Response.error();
      }
    })());
    return;
  }

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response.ok && response.type !== 'opaque') cache.put(request, response.clone()).catch(() => {});
      return response;
    } catch {
      return Response.error();
    }
  })());
});
